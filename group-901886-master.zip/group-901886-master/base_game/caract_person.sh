#!/bin/bash

hp1=60
str1=15
hp2=30
str2=5
hp3=150
str3=20
etap=1
answer=$1
hpmax=$hp

function option() {
    while IFS=";" read -r id name hp mp str int res spd luck race class rarety; do

	while [[ $hp1 -gt 0 ]] || [[ $hp2 -gt 0 ]] ; do

	    if [[$etap -eq 1]] || [[ $answer -eq 1 ]] ; then
		echo "$hp2"
		hp2=$(( $hp2 - $str1 ))

	    elif [[ $answer -eq 0 ]]; then
		echo "$hp1"
		hp1=$(( $hp1 + ($hpmax/2) ))

	    else
		echo "Choisissez en 0 pour attaquer ou 1 pour Soigner"
	    fi
}

function expulsion() {

    if [[ $hp2 -eq 0 ]]; then
	echo "Courage pour la suite"
	echo $etap
	etap=$(( $etap + 1 ))

    else [[ $hp1 -eq 0]]
	 echo "Dommage"
	 hp1=0

     fi 
   done 
done < bosses.csv enemies.csv players.csv
    

