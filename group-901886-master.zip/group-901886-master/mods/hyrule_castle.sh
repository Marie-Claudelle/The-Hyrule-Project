#!/bin/bash

#Importation des mods

source better_combat_options.sh
action3="3. Escape"
action4="4. Protect"

#Personnages

function GetPlayerStats() {
    first_line=0
    while IFS=',' read -r id name hp mp str int def res spd luck race class rarity; do
        if [[ $first_line -ne 0 ]]; then
            if [[ $id -eq $1 ]]; then
                player_name=$name
                hp1=$hp
                player_mp=$mp
                str1=$str
                player_int=$int
                player_def=$def
                player_res=$res
                player_spd=$spd
                player_luck=$luck
                player_rarity=$rarity
            fi
        else
            first_line=1
        fi
    done < ../players.csv
}

#Listing Ennemies

function GetEnemyStats() {
    first_line=0
    while IFS=',' read -r id name hp mp str int def res spd luck race class rarity; do
        if [[ $first_line -ne 0 ]]; then
            if [[ $id -eq $1 ]]; then
                enemy_Name=$name
                hp2=$hp
                enemy_mp=$mp
                str2=$str
                enemy_int=$int
                enemy_def=$def
                enemy_res=$res
                enemy_spd=$spd
                enemy_luck=$luck
                enemy_rarity=$rarity
            fi
        else
            first_line=1
	fi
    done < ../enemies.csv
}

function GetBossStats() {
    first_line=0
    while IFS=',' read -r id name hp mp str int def res spd luck race class rarity; do
        if [[ $first_line -ne 0 ]]; then
            if [[ $id -eq $1 ]]; then
                boss_name=$name
                hp3=$hp
                boss_mp=$mp
                st3=$str
                boss_int=$int
                boss_def=$def
                boss_res=$res
                boss_spd=$spd
                boss_luck=$luck
                boss_rarity=$rarity
            fi
        else
	    first_line=1
        fi
    done < ../bosses.csv
}

#Gestion combats- ennemis

function Combat_Enemy()  {
    echo -e "===== FIGHT "$etap" ======\nEnemy: "$enemy_name"\nHP: "$EnemyCurrHP"/"$hp2"\n"
    echo -e "Player: "$player_name"\nHP: "$PlayerCurrHP"/"$hp1
    echo -e "---Options--------\n1. Attack  2. Heal  "$action3  $action4"\nDefinir le numero et le nom de l'action choisie de la maniere suivante ( ex: 1. Attack)"
    read action
    if [[ $action = "1. Attack" ]]; then
        EnemyCurrHP=$(($EnemyCurrHP-$str1))
        PlayerCurrHP=$(($PlayerCurrHP-$str2))
        etap=$(($etap+1))
        echo -e "You attacked and dealt "$str1" damages !\n\n"$enemy_name "attacked and dealt "$str2" damages !"
    elif [[ $action = "2. Heal"  ]]; then
        PlayerCurrHP=$(($PlayerCurrHP-$str2))
        PlayerCurrHP=$(($PlayerCurrHP+($hp1/2)))
        if [[ $PlayerCurrHP -gt $hp1 ]]; then
            PlayerCurrHP=$hp1
        fi
        etap=$(($etap+1))
        echo -e "You used health !\n"$enemy_name" attacked and dealt "$str2 "damages !"
    elif [[ $action = "4. Protect" ]]; then
        Enemy_protection
    fi
    if [[ $PlayerCurrHP -le 0 ]]; then
        echo "You are dead !"
        exit 0
    fi
}

function Combat_Boss() {
    echo -e "===== FIGHT "$etap" ======\nBoss: "$boss_name"\nHP: "$BossCurrHP"/"$hp3"\n"
    echo -e "Player: "$player_name"\nHP: "$PlayerCurrHP"/"$hp1
    echo -e "---Options--------\n1. Attack  2. Heal  "$action3  $action4"\nDefinir le numero et le nom de l'action choisie de la maniere suivante ( ex: 1. Attack)
"
    read action
    if [[ $action = "1. Attack" ]]; then
        BossCurrHP=$(($BossCurrHP-$str1))
        PlayerCurrHP=$(($PlayerCurrHP-$str3))
        etap=$(($etap+1))
        echo -e "You attacked and dealt "$str1" damages !\n\n"$boss_name "attacked and dealt "$str3" damages !"
    elif [[ $action = "2. Heal"  ]]; then
        PlayerCurrHP=$(($PlayerCurrHP-$str3))
        PlayerCurrHP=$(($PlayerCurrHP+($hp1/2)))
        if [[ $PlayerCurrHP -gt $hp1 ]]; then
            PlayerCurrHP=$hp1
        fi
        etap=$(($etap+1))
        echo -e "You used heal !\n"$boss_name" attacked and dealt "$str3 "damages !"
    elif [[ $action = "4. Protect" ]]; then
        Boss_protection
    fi
    if [[ $PlayerCurrHP -le 0 ]]; then
        echo "You are dead !"
        exit 0
    fi
}

#la rarete est produite avec la creation d'une liste presentant  50 fois 1, 30 fois 2, 15 fois 3, 4 fois 4 et une fois 5

declare -a array=($(for i in {1..50}; do echo 1; done))
array+=($(for i in {1..30}; do echo 2; done))
array+=($(for i in {1..15}; do echo 3; done))
array+=($(for i in {1..4}; do echo 4; done))
array+=(5)

#On selectionne au hasard une valeur de la liste array pour determiner la rareté
#recherche des informations dans les fichiers csv et definitions du personnage de facon aleatoire.

function GenerPlayerID {
    GenRarity=${array[$(shuf -i 0-99 -n 1)]}
    declare -a listID
    lenlist=0
    while IFS=',' read -r id name hp mp str int def res spd luck race class rarity; do
        if [[ $rarity -eq $GenRarity ]] 2> /dev/null; then
            listID+=($id)
            lenlist=$((lenlist+1))
        fi
    done < ../players.csv
    PlayerID=${listID[$(shuf -i 0-$((lenlist-1)) -n 1)]}
}

function GenerEnemyID {
    GenRarity=${array[$(shuf -i 0-99 -n 1)]}
    declare -a listID
    lenlist=0
    while IFS=',' read -r id name hp mp str int def res spd luck race class rarity; do
        if [[ $rarity -eq $GenRarity ]] 2> /dev/null; then
            listID+=($id)
            lenlist=$((lenlist+1))
        fi
    done < ../enemies.csv
    EnemyID=${listID[$(shuf -i 0-$((lenlist-1)) -n 1)]}
}

function GenerBossID {
    GenRarity=${array[$(shuf -i 0-99 -n 1)]}
    declare -a listID
    lenlist=0
    while IFS=',' read -r id name hp mp str int def res spd luck race class rarity; do
        if [[ $rarity -eq $GenRarity ]] 2> /dev/null; then
            listID+=($id)
            lenlist=$((lenlist+1))
        fi
    done < ../bosses.csv
    BossID=${listID[$(shuf -i 0-$((lenlist-1)) -n 1)]}
}

#Initialison le jeu

GenerPlayerID

GetPlayerStats $PlayerID

Floor=1
MaxFloor=10
PlayerCurrHP=$hp1

#On renouvelle les etapes au niveau des differents etages

while [[ $Floor -lt $MaxFloor ]]; do
    GenerEnemyID
    GetEnemyStats $EnemyID
    EnemyCurrHP=$hp2
    etap=1
    echo "====== FLOOR" $Floor "======"
    echo "You encountered a "$enemy_name
    while [[ $EnemyCurrHP -gt 0 ]]; do
        Combat_Enemy
        if [[ $action = $action3 ]]; then
            PlayerEscape
            break
        fi
    done
    if [[ $EnemyCurrHP -le 0 ]]; then
        echo $enemy_name "died !"
        etap=$(($etap+1))
    fi
done

#Combat boss

GenerBossID
GetBossStats $BossID
BossCurrHP=$hp3
etap=1
echo -e "====== FLOOR" $Floor "========\n Ready for fighting against "$boss_name "!"
while [[ $BossCurrHP -gt 0 ]]; do
    Combat_Boss
    if [[ $action = $action3 ]]; then
        PlayerEscape
        break
    fi
done
echo $boss_name " You Win!"
