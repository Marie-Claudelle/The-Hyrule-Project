#!/bin/bash

function Player_Escape() {
    echo "Please return to the game!"
    Floor=1
}

function Boss_protection {

    damage=$(($STR3/2))
    hp1=$(($hp1-$damage))
    etap=$(($etap+1))
    echo -e "You protected yourself !\n"$BossName" attacked and health "$damage "damages !"


} 

function Enemy_protection() {
    damage=$(($STR2/2))
    hp1=$(($hp1-$damage))
    etap=$(($etap+1))
    echo -e "You protected yourself !\n"$EnemyName" attacked and health "$damage "damages !"
}
